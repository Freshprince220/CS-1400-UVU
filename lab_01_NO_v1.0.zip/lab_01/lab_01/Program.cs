﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// File Prologue
// Name: Nate O'Neal
// Project: lab01
// Date: 05/11/2017


// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying 
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.

namespace lab_01
{
    class Program
    {
        static void Main(string[] args)
        {
            //This Program displays my student info
            string name = "Nate O'neal";
            string course = "CS 1400";
            string section = "X01";
            string project = "Lab One";

            // This code displays the srings on the console
            Console.WriteLine("Name: {0}", name);
            Console.WriteLine("Course: {0}", course);
            Console.WriteLine("Section: {0}", section);
            Console.WriteLine("Project: {0}", project);

            Console.WriteLine("Press any key to continue");
            Console.ReadKey(true);

            Console.ReadLine();


        }// End main
    } // End class Program
} // End Namespace 
